const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const port = 3000;
let submittedFeedbacks = []; 
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public'))); 
app.get('/', (req, res) => {
    res.render('form', { title: 'Feedback Form' });
});
app.post('/submit-feedback', (req, res) => {
    const { name, email, whatsapp, feedback } = req.body;
    const timestamp = new Date();

    const newFeedback = {
        id: Date.now().toString(), 
        name,
        email,
        whatsapp,
        feedback,
        timestamp
    };

    submittedFeedbacks.push(newFeedback);

    res.render('submitted', {
        title: 'Feedback Received',
        name,
        email,
        whatsapp,
        feedback,
        timestamp
    });
});

app.get('/admin/dashboard', (req, res) => {
    res.render('admin-dash', { 
        title: 'Admin Dashboard - Laporan Feedback',
        reports: submittedFeedbacks.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)),
        reportsJSON: JSON.stringify(submittedFeedbacks) 
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});