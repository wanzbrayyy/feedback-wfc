const express = require('express');
const axios = require('axios');
const multer = require('multer');
const ffmpeg = require('fluent-ffmpeg');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(express.json());
app.use(express.static('public')); 
const upload = multer({ dest: 'uploads/' });
const LEAKCHECK_API_KEY = '0eb8985e476f3e6396278764b4337985e2a28c0c';
const INTELX_API_KEY = 'e6a53b47-650a-41d9-bee2-6da5d5b4e39f';
async function leakCheckApi(query) {
  try {
    const url = `https://api.leakcheck.net/v2?key=${LEAKCHECK_API_KEY}&query=${encodeURIComponent(query)}`;
    const resp = await axios.get(url);
    if (resp.data.status !== 'success') {
      return { source: 'LeakCheck', error: 'No data or error' };
    }
    return { source: 'LeakCheck', data: resp.data };
  } catch (err) {
    return { source: 'LeakCheck', error: err.message };
  }
}
async function intelxApi(query) {
  try {
    const url = `https://free.intelx.io/?apikey=${INTELX_API_KEY}&q=${encodeURIComponent(query)}`;
    const resp = await axios.get(url);
    if (!resp.data || !resp.data.results) {
      return { source: 'IntelX', error: 'No data or error' };
    }
    return { source: 'IntelX', data: resp.data };
  } catch (err) {
    return { source: 'IntelX', error: err.message };
  }
}
app.post('/api/leak-check', async (req, res) => {
  const query = req.body.query;
  if (!query) return res.status(400).json({ error: 'Query is required' });

  try {
    const [leakCheckRes, intelXRes] = await Promise.all([
      leakCheckApi(query),
      intelxApi(query),
    ]);

    // Combine results
    res.json({
      query,
      results: [leakCheckRes, intelXRes],
    });
  } catch (err) {
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});
app.post('/api/anon-voice', upload.single('audio'), (req, res) => {
  if (!req.file) return res.status(400).send('No audio file uploaded.');

  const inputPath = req.file.path;
  const outputPath = path.join('uploads', `anon_${Date.now()}.mp3`);

  ffmpeg(inputPath)
    .audioFilter([
      'asetrate=44100*0.8',
      'aecho=0.8:0.88:60:0.4',
      'acrusher=level_in=64:level_out=64:bits=8:mode=log:aa=1'
    ])
    .format('mp3')
    .on('end', () => {
      res.sendFile(path.resolve(outputPath), err => {
        fs.unlink(inputPath, () => {});
        fs.unlink(outputPath, () => {});
      });
    })
    .on('error', (err) => {
      console.error('FFmpeg error:', err);
      fs.unlink(inputPath, () => {});
      res.status(500).send('Audio processing failed.');
    })
    .save(outputPath);
});

app.listen(PORT, () => {
  console.log(`wwnzofc tech running on port ${PORT}`);
});
